This archive contains the full submission package for:
"A New Formula for the Inverse Laplace Transform: The Kyungu Formula"

Files included:
- kyungu-inverse-laplace-article.tex : Main LaTeX source
- kyungu-inverse-laplace-article.pdf : Compiled version (please compile using Overleaf if missing)
- README.txt : This file

Author:
Prof. Pathy Kyungu
Email: leprofesseurkyungu@gmail.com
GitHub Page: https://pathykyungu.github.io